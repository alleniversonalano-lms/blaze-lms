<?php
require $_SERVER['DOCUMENT_ROOT'] . '/config/db.php';
require $_SERVER['DOCUMENT_ROOT'] . '/config/utils.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Phone CRM</title>

    <!-- External CSS (Bootstrap CDN) -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0-alpha1/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0-alpha1/js/bootstrap.bundle.min.js"></script>

    <!-- jQuery for AJAX -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <style>
        /* Custom Theme Color */
        :root {
            --bg-color: #00897b;
            /* Navy blue */
            --accent-color: #004d40;
            /* Darker green */
            --text-color: #fff;
            /* White text */
        }

        /* Body background */
        body {
            background-color: var(--bg-color);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0;
        }

        /* Flexbox container for login and description sections */
        .auth-container {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
            max-width: 1200px;
        }

        /* Centering the login container */
        .login-container {
            background-color: #fff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            margin-right: 30px;
        }

        /* Styling login form elements */
        .login-container h2 {
            text-align: center;
            color: var(--accent-color);
            font-size: 2rem;
            margin-bottom: 20px;
        }

        .login-container .form-control {
            border-radius: 4px;
            font-size: 1rem;
            padding: 12px;
        }

        .btn-primary {
            background-color: var(--bg-color);
            border-color: var(--bg-color);
            font-size: 1.1rem;
            padding: 12px;
            border-radius: 4px;
        }

        .btn-primary:hover {
            background-color: var(--accent-color);
            border-color: var(--accent-color);
        }

        /* Description Section Styling */
        .description-container {
            color: var(--text-color);
            max-width: 500px;
            padding: 20px;
            font-size: 1.2rem;
            line-height: 1.6;
        }

        .description-container h3 {
            font-size: 2rem;
            color: #fff;
            margin-bottom: 15px;
        }

        .description-container p {
            font-size: 1.1rem;
            margin-bottom: 20px;
            font-weight: 400;
        }

        .description-container .highlight {
            font-weight: 600;
            color: #ff7043;
            /* Complementary coral color */
        }

        /* Toast Container */
        #toast-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1050;
        }

        /* Toast Styling */
        .toast {
            margin-bottom: 10px;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="auth-container">
            <!-- Login Form -->
            <div class="login-container mt-5">
                <h2>Login</h2>
                <form id="login-form" method="POST">
                    <div class="mb-3">
                        <label for="email" class="form-label">Email:</label>
                        <input type="email" name="email" id="email" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password:</label>
                        <input type="password" name="password" id="password" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Login</button>
                </form>
            </div>

            <!-- Description Section -->
            <div class="description-container">
                <h3>Welcome to <span class="highlight">Callify™</span></h3>
                <p><span class="highlight">Transform your customer interactions</span> and improve your business's efficiency.</p>
                <p>Callify™ is designed to streamline your <strong>phone calls, leads, and customer relationships</strong>. Manage your contacts effortlessly, stay on top of your sales, and boost productivity with ease.</p>
                <p>Login now and start managing your leads like a pro!</p>
            </div>
        </div>
    </div>

    <!-- Toast Container (for Bootstrap Toast) -->
    <div id="toast-container"></div>

    <!-- Toast Script (Bootstrap) -->
    <script>
        // Show Bootstrap Toast
        function showToast(message, type = "success", duration = 3000) {
            const toastContainer = document.getElementById("toast-container");

            // Create Toast Element
            const toast = document.createElement("div");
            toast.classList.add("toast", "align-items-center", "text-white", "bg-" + type, "border-0");
            toast.setAttribute("role", "alert");
            toast.setAttribute("aria-live", "assertive");
            toast.setAttribute("aria-atomic", "true");

            // Toast Content
            toast.innerHTML = `
                <div class="d-flex">
                    <div class="toast-body">
                        ${message}
                    </div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
            `;

            // Append the toast to the container
            toastContainer.appendChild(toast);

            // Initialize the Toast
            const bsToast = new bootstrap.Toast(toast);
            bsToast.show();

            // Remove the toast after duration
            setTimeout(() => {
                toastContainer.removeChild(toast);
            }, duration);
        }

        // Handle form submission with AJAX
        $("#login-form").submit(function(e) {
            e.preventDefault(); // Prevent the default form submission

            const formData = $(this).serialize(); // Serialize the form data

            $.ajax({
                type: "POST",
                url: "/public/login_process", // The PHP file that handles login
                data: formData,
                dataType: "json",
                success: function(response) {
                    if (response.status === "success") {
                        showToast(response.message, "success", 3000);
                        setTimeout(function() {
                            window.location.href = "/public/dashboard.php"; // Redirect after successful login
                        }, 3000);
                    } else {
                        showToast(response.message, "danger", 3000);
                    }
                },
                error: function() {
                    showToast("An error occurred. Please try again.", "danger", 3000);
                }
            });
        });
    </script>
</body>

</html>