<?php
require $_SERVER['DOCUMENT_ROOT'] . '/config/db.php';
require $_SERVER['DOCUMENT_ROOT'] . '/config/utils.php';

session_start(); // Ensure session is started

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: /public/index.php"); // Redirect to login if not authenticated
    exit();
}

$user_name = $_SESSION['name'] ?? 'User';
$user_role = $_SESSION['role'] ?? 'Unknown';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contacts - Callify™</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0-alpha1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
</head>

<body>
    <?php include('../includes/topbar.php'); ?>
    <div class="container mt-4">
        <h2>Contacts</h2>
        <hr>
        <p>Welcome, <strong><?php echo htmlspecialchars($user_name); ?></strong> (<?php echo htmlspecialchars($user_role); ?>)</p>
        <div class="card shadow-lg p-3">
            <div class="table-responsive">
                <table id="contactsTable" class="table table-striped table-bordered" style="width:100%; font-size:10px;">
                    <thead class="table-light">
                        <tr>
                            <th><input type="text" class="form-control form-control-sm" placeholder="Search ID"></th>
                            <th><input type="text" class="form-control form-control-sm" placeholder="Search Name"></th>
                            <th><input type="text" class="form-control form-control-sm" placeholder="Search Phone"></th>
                            <th><input type="text" class="form-control form-control-sm" placeholder="Search Fax"></th>
                            <th><input type="text" class="form-control form-control-sm" placeholder="Search Email"></th>
                            <th><input type="text" class="form-control form-control-sm" placeholder="Search City"></th>
                            <th><input type="text" class="form-control form-control-sm" placeholder="Search State"></th>
                            <th><input type="text" class="form-control form-control-sm" placeholder="Search Zip"></th>
                            <th><input type="text" class="form-control form-control-sm" placeholder="Search Status" disabled hidden></th>

                        </tr>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Phone</th>
                            <th>Fax</th>
                            <th>Email</th>
                            <th>City</th>
                            <th>State</th>
                            <th>Zip</th>
                            <th>Action</th>

                        </tr>
                    </thead>
                    <tfoot>

                    </tfoot>
                </table>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            let table = $('#contactsTable').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax": "/transactions/fetch_contacts",
                "order": [
                    [1, "asc"]
                ],
                "initComplete": function() {
                    this.api().columns().every(function() {
                        let column = this;
                        $('input', this.footer()).on('keyup change', function() {
                            if (column.search() !== this.value) {
                                column.search(this.value).draw();
                            }
                        });
                    });
                }
            });
        });
    </script>
</body>

</html>