<?php
require $_SERVER['DOCUMENT_ROOT'] . '/config/db.php';
require $_SERVER['DOCUMENT_ROOT'] . '/config/utils.php';





// Fetch user info
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['role'];
$user_name = $_SESSION['name'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Callify™</title>
    
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0-alpha1/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0-alpha1/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    
    <style>
        :root {
            --primary-color: #00897b;
            --accent-color: #004d40;
            --bg-light: #f4f6f9;
        }
        body {
            background-color: var(--bg-light);
        }
        .sidebar {
            background-color: var(--primary-color);
            height: 100vh;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            padding-top: 20px;
        }
        .sidebar a {
            color: white;
            display: block;
            padding: 15px;
            text-decoration: none;
        }
        .sidebar a:hover {
            background-color: var(--accent-color);
        }
        .content {
            margin-left: 250px;
            padding: 20px;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h4 class="text-center text-white">Callify™</h4>
        <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
        <a href="contacts.php"><i class="fas fa-address-book"></i> Contacts</a>
        <a href="leads.php"><i class="fas fa-user-plus"></i> Leads</a>
        <a href="calls.php"><i class="fas fa-phone"></i> Calls</a>
        <a href="reports.php"><i class="fas fa-chart-line"></i> Reports</a>
        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h2>Welcome, <?php echo htmlspecialchars($user_name); ?>!</h2>
                    <hr>
                    <p>Access Type: <strong><?php echo ucfirst($user_role); ?></strong></p>
                </div>
            </div>
            <div class="row mt-4">
                <div class="col-md-4">
                    <div class="card p-3">
                        <h4><i class="fas fa-phone text-primary"></i> Total Calls</h4>
                        <p><strong>120</strong></p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card p-3">
                        <h4><i class="fas fa-user text-success"></i> Active Leads</h4>
                        <p><strong>35</strong></p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card p-3">
                        <h4><i class="fas fa-chart-line text-warning"></i> Conversion Rate</h4>
                        <p><strong>28%</strong></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>