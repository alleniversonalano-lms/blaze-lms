<?php
require $_SERVER['DOCUMENT_ROOT'] . '/config/db.php';
require $_SERVER['DOCUMENT_ROOT'] . '/config/utils.php';

// Check if the form was submitted via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = sanitizeInput($_POST['email']);
    $password = $_POST['password'];

    // Attempt login
    if (loginUser($email, $password)) {
        // On successful login, return a success message
        echo json_encode(['status' => 'success', 'message' => 'Login successful!']);
    } else {
        // On failed login, return an error message
        echo json_encode(['status' => 'error', 'message' => 'Invalid email or password.']);
    }
}

// Function to check user credentials
function loginUser($email, $password)
{
    global $mysqli;

    // Prepare SQL statement to avoid SQL injection
    $stmt = $mysqli->prepare("SELECT id, password, role, name FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();

    // Get the result
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // User found, verify password
        $user = $result->fetch_assoc();

        if (password_verify($password, $user['password'])) {
            // Password is correct, set session variables
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['name'] = $user['name'];
            return true;
        }
    }

    // Invalid credentials
    return false;
}
