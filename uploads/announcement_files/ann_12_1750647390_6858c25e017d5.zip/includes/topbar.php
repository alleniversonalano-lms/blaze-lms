<?php

$user_name = isset($_SESSION['name']) ? $_SESSION['name'] : 'Guest';
?>

<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #00897b;">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Callify™</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="contacts.php">Contacts</a></li>
                <li class="nav-item"><a class="nav-link" href="leads.php">Leads</a></li>
                <li class="nav-item"><a class="nav-link" href="calls.php">Calls</a></li>
                <li class="nav-item"><a class="nav-link" href="reports.php">Reports</a></li>
            </ul>
            <span class="navbar-text me-3">Welcome, <?php echo htmlspecialchars($user_name); ?>!</span>
            <a href="logout.php" class="btn btn-outline-light">Logout</a>
        </div>
    </div>
</nav>
