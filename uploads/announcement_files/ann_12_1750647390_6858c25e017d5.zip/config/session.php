<?php
session_start();
require $_SERVER['DOCUMENT_ROOT'].'/config/db.php';

// Function to check if user is logged in
function checkLogin() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: /public/index.php");
        exit();
    }
}

// Function to check user role
function checkRole($allowed_roles) {
    if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], $allowed_roles)) {
        header("Location: /public/dashboard.php"); // Redirect to dashboard if unauthorized
        exit();
    }
}

// Function to log in a user
function loginUser($email, $password) {
    global $conn;
    $stmt = $conn->prepare("SELECT id, name, role, password FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['role'] = $user['role'];
            header("Location: /public/dashboard.php");
            exit();
        }
    }
    return false;
}

// Function to log out a user
function logoutUser() {
    session_unset();
    session_destroy();
    header("Location: /public/index.php");
    exit();
}
?>