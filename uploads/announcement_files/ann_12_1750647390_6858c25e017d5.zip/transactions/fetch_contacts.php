<?php
require $_SERVER['DOCUMENT_ROOT'] . '/config/db.php'; // Include DB connection
require $_SERVER['DOCUMENT_ROOT'] . '/config/utils.php'; // Include utility functions

// Server-side processing variables
$start = $_GET['start']; // Starting point for pagination
$length = $_GET['length']; // Number of records to show per page
$search = $_GET['search']['value']; // Search input value
$order_column = $_GET['order'][0]['column']; // Column to order by
$order_dir = $_GET['order'][0]['dir']; // Ascending or descending order

// Columns array to map the correct column index from DataTable
$columns = ['id', 'name', 'phone', 'fax', 'email', 'city', 'state', 'rating', 'status'];

// Build the ORDER BY clause based on DataTables' input
$order_by = $columns[$order_column] . ' ' . $order_dir;

// Build the WHERE clause for search (if search value is provided)
$where_clause = '';
if ($search) {
    $search = "%" . $conn->real_escape_string($search) . "%"; // Escape search string
    $where_clause = "WHERE name LIKE ? OR phone LIKE ? OR fax LIKE ? OR email LIKE ? OR city LIKE ? OR state LIKE ?";
}

// Prepare the SQL query for total records count
$total_query = "SELECT COUNT(*) as total FROM prospects $where_clause";
$total_result = $conn->prepare($total_query);

if ($where_clause) {
    $total_result->bind_param('ssssss', $search, $search, $search, $search, $search, $search);
}

$total_result->execute();
$total_data = $total_result->get_result()->fetch_assoc();
$total_records = $total_data['total'];

// Prepare the SQL query to fetch data based on pagination and search
$query = "SELECT id, name, phone, fax, email, city, state, zip FROM prospects $where_clause ORDER BY $order_by LIMIT ?, ?";
$result = $conn->prepare($query);

if ($where_clause) {
    $result->bind_param('ssssss', $search, $search, $search, $search, $search, $search);
    $result->bind_param('ii', $start, $length);
} else {
    $result->bind_param('ii', $start, $length);
}

$result->execute();
$data = $result->get_result();

// Prepare the output for DataTable
$contacts = [];
while ($row = $data->fetch_assoc()) {
    $contacts[] = [
        'id' => $row['id'],
        'name' => $row['name'],
        'phone' => $row['phone'],
        'fax' => $row['fax'],
        'email' => $row['email'],
        'city' => $row['city'],
        'state' => $row['state'],
        'zip' => $row['zip'],
        'action' => '<a href="/contacts/edit.php?id=' . $row['id'] . '" class="btn btn-sm btn-primary"><i class="fas fa-edit"></i> Edit</a>'
    ];
}

// Return JSON response
$response = [
    'draw' => $_GET['draw'],
    'recordsTotal' => $total_records,
    'recordsFiltered' => $total_records,
    'data' => $contacts
];

echo json_encode($response);
?>
