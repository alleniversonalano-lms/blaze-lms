<?php
require $_SERVER['DOCUMENT_ROOT'] . '/config/db.php';
require $_SERVER['DOCUMENT_ROOT'] . '/config/utils.php';

session_start(); // Ensure session is started

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: /public/index.php"); // Redirect to login if not authenticated
    exit();
}

// Get user details from session
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['role'];
$user_name = isset($_SESSION['name']) ? $_SESSION['name'] : 'User'; // Fetch name if stored in session

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Callify™</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0-alpha1/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0-alpha1/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <!-- Include Topbar -->
    <?php include('../includes/topbar.php'); ?>

    <div class="container mt-4">
        <h2>Welcome, <?php echo htmlspecialchars($user_name); ?>!</h2>
        <hr>
        <p>Access Type: <strong><?php echo htmlspecialchars($user_role); ?></strong></p>
        
        <!-- Dashboard Cards -->
        <div class="row">
            <div class="col-md-4">
                <div class="card p-3 shadow">
                    <h4><i class="fas fa-users text-primary"></i> Total Users</h4>
                    <p><strong>10</strong></p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-3 shadow">
                    <h4><i class="fas fa-phone text-success"></i> Total Calls</h4>
                    <p><strong>150</strong></p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-3 shadow">
                    <h4><i class="fas fa-chart-line text-warning"></i> Conversion Rate</h4>
                    <p><strong>20%</strong></p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
