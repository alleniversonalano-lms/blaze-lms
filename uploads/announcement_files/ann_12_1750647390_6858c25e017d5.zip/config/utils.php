<?php
require $_SERVER['DOCUMENT_ROOT'] . '/config/db.php';

// Set custom session name



// Function to check if a user is an admin
function isAdmin()
{
    return isset($_SESSION['role']) && $_SESSION['role'] === 'Admin';
}

// Function to check if a user is a supervisor
function isSupervisor()
{
    return isset($_SESSION['role']) && $_SESSION['role'] === 'Supervisor';
}

// Function to check if a user is an agent
function isAgent()
{
    return isset($_SESSION['role']) && $_SESSION['role'] === 'Agent';
}

// Function to check if a user is a field agent
function isFieldAgent()
{
    return isset($_SESSION['role']) && $_SESSION['role'] === 'Field Agent';
}

// Function to sanitize input data
function sanitizeInput($data)
{
    global $conn;
    return htmlspecialchars(strip_tags(trim($conn->real_escape_string($data))));
}

// Function to redirect unauthorized users
function redirectUnauthorized($allowed_roles)
{
    if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], $allowed_roles)) {
        header("Location: /public/dashboard.php");
        exit();
    }
}

?>
