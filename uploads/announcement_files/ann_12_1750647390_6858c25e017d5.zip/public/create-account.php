<?php
require $_SERVER['DOCUMENT_ROOT'] . '/config/db.php';
require $_SERVER['DOCUMENT_ROOT'] . '/config/utils.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $role = trim($_POST['role']);
    $password = trim($_POST['password']); // User-defined password

    // Check if email already exists
    $checkQuery = "SELECT id FROM users WHERE email = ?";
    $stmt = $conn->prepare($checkQuery);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        echo json_encode(["status" => "error", "message" => "Email is already registered."]);
        exit;
    }
    $stmt->close();

    // Hash the password before storing
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Insert new user
    $query = "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssss", $name, $email, $hashedPassword, $role);
    
    if ($stmt->execute()) {
        // Redirect to register.php after account creation
        header("Location: /public/register");  // Adjust the path if necessary
        exit();
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to create account."]);
    }
    $stmt->close();
    $conn->close();
}
?>
